#!/usr/bin/env python3


class MonthReport:
    def __init__(self):
        pass